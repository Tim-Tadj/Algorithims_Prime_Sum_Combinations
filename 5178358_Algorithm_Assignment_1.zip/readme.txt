This program finds the number of prime sum combinations and prints the answer in the terminal window
Steps to run:
1) make a file called "Input.txt" where you enter the parameters in the format:
number_to_sum_to lower_limit_of_number_of_sums upper_limit_of_number_of_sums
e.g.
8 1 3

2) either put the file into the same folder as the python script and run the script 
or run the script with the PATH of the file as an arg variable

3) wait for program to print out result to the terminal